package com.tc.training.smallFinance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmallFinanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
