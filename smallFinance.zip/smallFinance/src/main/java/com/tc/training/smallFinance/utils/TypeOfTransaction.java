package com.tc.training.smallFinance.utils;

public enum TypeOfTransaction {

    WITHDRAWAL,DEPOSIT,TRANSFER,FD,GOLD_LOAN,PERSONAL_LOAN,HOME_LOAN,EDUCATION_LOAN,RD;

}
