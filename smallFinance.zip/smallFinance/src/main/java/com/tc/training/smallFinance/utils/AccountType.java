package com.tc.training.smallFinance.utils;

public enum AccountType {
    Savings;
}
