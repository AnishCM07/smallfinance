package com.tc.training.smallFinance.utils;

public enum PaymentStatus {

    PAID,UNPAID,UPCOMING

}
