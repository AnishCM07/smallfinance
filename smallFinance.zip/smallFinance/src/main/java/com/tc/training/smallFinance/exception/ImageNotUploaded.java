package com.tc.training.smallFinance.exception;

public class ImageNotUploaded extends RuntimeException{

    public ImageNotUploaded(String s){
        super(s);
    }
}
