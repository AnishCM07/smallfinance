package com.tc.training.smallFinance.utils;

public enum Status {

    UNDER_REVIEW, APPROVED, REJECTED
}
