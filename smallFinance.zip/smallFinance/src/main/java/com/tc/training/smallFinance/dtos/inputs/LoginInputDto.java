package com.tc.training.smallFinance.dtos.inputs;

import lombok.Data;

@Data
public class LoginInputDto {

    private String accountNumber;

    private String password;

}
