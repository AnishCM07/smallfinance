package com.tc.training.smallFinance.exception;

public class ElementNotFound extends RuntimeException {
    public ElementNotFound(String s) {
        super(s);
    }
}
