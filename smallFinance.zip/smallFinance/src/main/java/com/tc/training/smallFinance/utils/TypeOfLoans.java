package com.tc.training.smallFinance.utils;

public enum TypeOfLoans {

    GOLD_LOAN,HOME_LOAN,EDUCATION_LOAN,PERSONAL_LOAN
}
