package com.tc.training.smallFinance.exception;

public class MyMailException extends RuntimeException {

    public MyMailException (String message){
        super(message);
    }
}
