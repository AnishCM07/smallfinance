package com.tc.training.smallFinance.exception;

public class CustomException extends RuntimeException {
    public CustomException(String s) {
        super(s);
    }
}
