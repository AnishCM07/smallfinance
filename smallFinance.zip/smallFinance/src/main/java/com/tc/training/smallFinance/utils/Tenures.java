package com.tc.training.smallFinance.utils;

public enum Tenures {

    ONE_MONTH, THREE_MONTHS, SIX_MONTHS, ONE_YEAR;
}
