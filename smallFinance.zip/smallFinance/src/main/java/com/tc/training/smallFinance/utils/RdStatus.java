package com.tc.training.smallFinance.utils;

public enum RdStatus {

    ACTIVE, MATURED, CLOSED

}
