package com.tc.training.smallFinance.utils;

public enum TenureForLoans {

    ONE_YEAR

}
