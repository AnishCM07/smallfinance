package com.tc.training.smallFinance.utils;

public enum TransactionType {
    DEBITED,CREDITED
}

