package com.tc.training.smallFinance.utils;

public enum Role {
    CUSTOMER,MANAGER
}
