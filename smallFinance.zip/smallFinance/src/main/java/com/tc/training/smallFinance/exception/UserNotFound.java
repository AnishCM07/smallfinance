package com.tc.training.smallFinance.exception;

public class UserNotFound extends RuntimeException{
    public UserNotFound(String message){super(message);}
}
