package com.tc.training.smallFinance.dtos.inputs;

import lombok.Data;

@Data
public class OtpInputDto {

    private Long otp;

    private Long accountNumber;
}
